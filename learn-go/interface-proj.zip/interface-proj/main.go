package main

import (
	"interface-proj/data"
	"interface-proj/data/mysql"
)

func main() {
	m := mysql.NewConn(nil)
	data.S = &m
	data.S.Create("random data")
}
