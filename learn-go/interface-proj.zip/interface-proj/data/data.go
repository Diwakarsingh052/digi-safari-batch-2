package data

type Storer interface {
	Create(data string)
	Update(data string)
	Delete(data string)
}

var S Storer
